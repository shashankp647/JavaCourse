package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract implements CalcInterface {
    // TODO -- start your code here
    int total=0;
    @Override
    public String getResult(int argumentOne,int argumentTwo) {
        total =argumentOne-argumentTwo;
        return String.valueOf(total);
    }
}
