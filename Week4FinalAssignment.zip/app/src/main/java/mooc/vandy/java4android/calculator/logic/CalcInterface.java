package mooc.vandy.java4android.calculator.logic;



/*Defines interface to get result. Individual classes will override existing method in the Interface to do the implementation
*/
public interface CalcInterface {

    public String getResult(int argumentOne, int argumentTwo);

}