package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Divide operation.
 */
public class Divide implements CalcInterface{
    // TODO -- start your code here
    int Q;
    int R;
    @Override
    public String getResult(int argumentOne,int argumentTwo){
       //check if Value Two is Zero
        if(argumentTwo==0){
            return "**** Division by 0 not possible ****  ";
        }
        else {
            Q=argumentOne/argumentTwo;
            R=argumentOne%argumentTwo;
            return String.valueOf(Q)+" R:"+String.valueOf(R);

        }
    }
}
