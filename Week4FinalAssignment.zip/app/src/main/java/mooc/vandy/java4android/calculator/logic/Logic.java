package mooc.vandy.java4android.calculator.logic;

import mooc.vandy.java4android.calculator.logic.Add;
import mooc.vandy.java4android.calculator.logic.Divide;
import mooc.vandy.java4android.calculator.logic.Multiply;
import mooc.vandy.java4android.calculator.logic.Subtract;
import mooc.vandy.java4android.calculator.ui.ActivityInterface;

/**
 * Performs an operation selected by the user.
 * In this assignment we will be using Interface class CalcInterface to have a common method for each operation class
 */
public class Logic 
       implements LogicInterface {
    /**
     * Reference to the Activity output.
     */
    protected ActivityInterface mOut;

    /**
     * Constructor initializes the field.
     */
    public Logic(ActivityInterface out){
        mOut = out;
    }

    /**
     * Perform the @a operation on @a argumentOne and @a argumentTwo.
     *
     *
     */
    private static int addition=1;
    private static int subraction=2;
    private static int multiplication=3;
    private static int division=4;

    public void process(int argumentOne,
                        int argumentTwo,
                        int operation){
        // TODO -- start your code here
        if(operation==1){
            Add add = new Add();
            mOut.print(add.getResult(argumentOne, argumentTwo));

        } else if (operation == 2) {
            Subtract sub=new Subtract();
            mOut.print(sub.getResult(argumentOne,argumentTwo));
        }
        else if (operation== 3){
            Multiply mul =new Multiply();
            mOut.print(mul.getResult(argumentOne,argumentTwo));
        }
        else {
            Divide div= new Divide();
            mOut.print(div.getResult(argumentOne,argumentTwo));
        }
    }
}
