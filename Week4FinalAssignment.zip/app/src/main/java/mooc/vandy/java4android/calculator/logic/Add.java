package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add implements CalcInterface {
    // TODO -- start your code here

    //Initially tried implementing without Interface
   /* int input1;
    int input2;
    int total;
    public Add(int argumentOne,int argumentTwo){
        input1=argumentOne;
        input2=argumentTwo;

    }*/
   int total=0;
    @Override
    public String getResult(int argumentOne,int argumentTwo){
        total=argumentOne+argumentTwo;
        return String.valueOf(total);
    }


}
